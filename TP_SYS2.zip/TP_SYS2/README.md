# TP_SYS2_SGF
TP DE SYSTEME D'EXPLOITATION Système de gestion de fichiers Linux

Compilation : gcc search.c -o search

Execution : ./search [repertoire] [options] Nom_de_Fichier

Note : Lors de l'utilisation de l'asterisk * il est préférable de taper '*' au lieu de * seulement pour eviter que le bash l'interprète
